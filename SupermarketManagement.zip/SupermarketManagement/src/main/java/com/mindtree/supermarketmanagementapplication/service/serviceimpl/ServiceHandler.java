package com.mindtree.supermarketmanagementapplication.service.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.supermarketmanagementapplication.entity.Customer;
import com.mindtree.supermarketmanagementapplication.entity.Item;
import com.mindtree.supermarketmanagementapplication.repository.CustomerRepository;
import com.mindtree.supermarketmanagementapplication.repository.ItemRepository;
import com.mindtree.supermarketmanagementapplication.service.CustomerService;
import com.mindtree.supermarketmanagementapplication.service.ItemService;

@Service
public class ServiceHandler implements CustomerService, ItemService {

	@Autowired
	CustomerRepository customerrepo;

	@Autowired
	ItemRepository itemrepo;

	Map<Integer, Double> amountMappedToCustomer = new HashMap<Integer, Double>();

	@Override
	public void addCustomer(Customer customer) {
		customerrepo.save(customer);
	}

	@Override
	public void addItem(Item item) {
		itemrepo.save(item);
	}

	@Override
	public Customer itemsPurchasedByCustomer(List<Item> items, int customerId) {
		Customer customer = customerrepo.getCustomerById(customerId);

		if (customer.equals(null))
			;
		else {
			double amount = 0;

			for (int i = 0; i < items.size(); i++) {
				amount += items.get(i).getPrice();
			}

			amountMappedToCustomer.put(customerId, amount);

			customer.getItems().addAll(items);
			customerrepo.save(customer);
		}

		System.out.println(amountMappedToCustomer);
		return customer;
	}

	@Override
	public List<Customer> getAllFemales() {
		List<Customer> allCustomer = customerrepo.findAll();
		List<Customer> femaleCustomer = new ArrayList<>();

		for (int i = 0; i < allCustomer.size(); i++) {
			if (allCustomer.get(i).getGender().equalsIgnoreCase("female")) {
				femaleCustomer.add(allCustomer.get(i));
			}
		}

		return null;
	}
}
