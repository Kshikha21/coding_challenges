package com.mindtree.supermarketmanagementapplication.service;

import java.util.List;
import com.mindtree.supermarketmanagementapplication.entity.Customer;
import com.mindtree.supermarketmanagementapplication.entity.Item;

public interface CustomerService {

	public void addCustomer(Customer customer);

	public Customer itemsPurchasedByCustomer(List<Item> items, int customerId);
	
	public List<Customer> getAllFemales();
}
