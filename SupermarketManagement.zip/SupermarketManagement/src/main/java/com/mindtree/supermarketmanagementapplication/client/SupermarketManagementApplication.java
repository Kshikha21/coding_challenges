package com.mindtree.supermarketmanagementapplication.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.mindtree.supermarketmanagementapplication")
@EnableJpaRepositories("com.mindtree.supermarketmanagementapplication")
@EntityScan("com.mindtree.supermarketmanagementapplication")

public class SupermarketManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupermarketManagementApplication.class, args);
	}

}
