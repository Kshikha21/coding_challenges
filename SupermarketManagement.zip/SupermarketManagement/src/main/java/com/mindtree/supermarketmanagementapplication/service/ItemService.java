package com.mindtree.supermarketmanagementapplication.service;

import com.mindtree.supermarketmanagementapplication.entity.Item;

public interface ItemService {

	public void addItem(Item item);
}
