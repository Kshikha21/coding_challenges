package com.mindtree.activity.exception;

public class ServiceException extends Exception {

}
