package com.mindtree.activity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivityAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivityAppApplication.class, args);
	}

}
